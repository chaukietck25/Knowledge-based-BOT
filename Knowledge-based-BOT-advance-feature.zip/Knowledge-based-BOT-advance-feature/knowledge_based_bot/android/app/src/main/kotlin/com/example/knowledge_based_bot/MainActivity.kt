package com.example.knowledge_based_bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
